<?php

/**
* @package AuzyTestPluin

*/

class AuzyTestPluginDeactivate {  
    public static function deactivate() {
        
    }

}


