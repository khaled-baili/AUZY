<?php

/**
* @package AuzyTestPluin

*/



class AuzyTestPluginActivate {  
    public static function activate() {
        
    }

}


